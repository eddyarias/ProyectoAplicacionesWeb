import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-carrito',
  // standalone: true,
  // imports: [],
  templateUrl: './inicio-carrito.component.html',
  styleUrl: './inicio-carrito.component.scss'
})
export class InicioCarritoComponent {

}
