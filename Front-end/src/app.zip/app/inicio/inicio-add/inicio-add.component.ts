import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-add',
  // standalone: true,
  // imports: [],
  templateUrl: './inicio-add.component.html',
  styleUrl: './inicio-add.component.scss'
})
export class InicioAddComponent {

}
