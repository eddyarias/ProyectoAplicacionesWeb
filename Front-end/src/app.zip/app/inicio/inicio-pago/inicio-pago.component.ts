import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-pago',
  // standalone: true,
  // imports: [],
  templateUrl: './inicio-pago.component.html',
  styleUrl: './inicio-pago.component.scss'
})
export class InicioPagoComponent {

}
