import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-filtrar',
  // standalone: true,
  // imports: [],
  templateUrl: './inicio-filtrar.component.html',
  styleUrl: './inicio-filtrar.component.scss'
})
export class InicioFiltrarComponent {

}
