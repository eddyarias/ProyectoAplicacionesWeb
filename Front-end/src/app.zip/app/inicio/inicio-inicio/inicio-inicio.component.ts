import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-inicio',
  // standalone: true,
  // imports: [],
  templateUrl: './inicio-inicio.component.html',
  styleUrl: './inicio-inicio.component.scss'
})
export class InicioInicioComponent {

}
